import { createHumanoid, animateHumanoid, setSeated, angleLerp, damp, clamp, groundHeight } from './utils.js';

const tmp = { x: 0, z: 0 };

export class Player {
  constructor(scene, physics) {
    this.scene = scene;
    this.physics = physics;
    this.model = createHumanoid({ shirt: 0x2f6fdf, pants: 0x1d2b44, skin: 0xe8b98f, hair: 0x2a1a10 });
    this.model.rotation.order = 'YXZ';
    scene.add(this.model);
    this.pos = { x: 0, y: 0, z: 0 };
    this.vx = 0; this.vz = 0; this.vy = 0;
    this.heading = 0;
    this.speed = 0;
    this.grounded = true;
    this.radius = 0.4;
    this.phase = 0;
    this.vehicle = null;
  }

  _detach() {
    const m = this.model;
    m.removeFromParent();
    this.scene.add(m);
    m.scale.setScalar(1);
    m.rotation.set(0, 0, 0);
    setSeated(m, false);
  }

  reset(sp) {
    if (this.vehicle) { this.vehicle.driven = false; this.vehicle = null; this._detach(); }
    this.pos.x = sp.x; this.pos.z = sp.z; this.pos.y = groundHeight(sp.x, sp.z);
    this.vx = this.vz = this.vy = 0;
    this.heading = Math.PI;
    this.grounded = true;
    this.sync();
  }

  update(dt, c, camYaw, vm) {
    if (this.vehicle) return;
    const f = (c.down('KeyW') ? 1 : 0) - (c.down('KeyS') ? 1 : 0);
    const s = (c.down('KeyD') ? 1 : 0) - (c.down('KeyA') ? 1 : 0);
    const sy = Math.sin(camYaw), cy = Math.cos(camYaw);
    // frente = (sin yaw, cos yaw); direita = (-cos yaw, sin yaw)
    let wx = sy * f - cy * s, wz = cy * f + sy * s;
    const len = Math.hypot(wx, wz);
    if (len > 0) { wx /= len; wz /= len; }
    const run = c.down('ShiftLeft') || c.down('ShiftRight');
    const target = len > 0 ? (run ? 9 : 4.5) : 0;
    const k = this.grounded ? 14 : 4;
    this.vx = damp(this.vx, wx * target, k, dt);
    this.vz = damp(this.vz, wz * target, k, dt);
    if (len > 0) this.heading = angleLerp(this.heading, Math.atan2(wx, wz), 1 - Math.exp(-14 * dt));

    this.pos.x += this.vx * dt;
    this.pos.z += this.vz * dt;
    vm.pushOut(this.pos, this.radius);
    this.physics.resolve(this.pos, this.radius, this.pos.y);

    if (c.wasPressed('Space') && this.grounded) { this.vy = 9.5; this.grounded = false; }
    this.physics.stepVertical(this, dt, groundHeight(this.pos.x, this.pos.z));

    this.speed = Math.hypot(this.vx, this.vz);
    this.phase += dt * (6 + this.speed * 0.9);
    const amt = this.grounded ? clamp(this.speed / 9, 0, 1) : 0.3;
    animateHumanoid(this.model, this.phase, amt);
  }

  // Mantém posição/orientação coerentes com o veículo quando o jogador está dirigindo.
  sync() {
    const v = this.vehicle;
    if (v) {
      this.pos.x = v.pos.x; this.pos.y = v.pos.y; this.pos.z = v.pos.z;
      this.heading = v.heading;
      this.speed = Math.abs(v.speed);
    } else {
      this.model.position.set(this.pos.x, this.pos.y, this.pos.z);
      this.model.rotation.y = this.heading;
    }
  }

  tryEnter(vm) {
    const v = vm.nearest(this.pos.x, this.pos.z, 4.2);
    if (!v) return false;
    this.vehicle = v;
    v.driven = true;
    const m = this.model;
    m.removeFromParent();
    v.group.add(m);
    m.position.set(v.seat.x, v.seat.y, v.seat.z);
    m.rotation.set(0, 0, 0);
    m.scale.setScalar(v.seat.s);
    setSeated(m, true);
    this.vx = this.vz = 0;
    return true;
  }

  tryExit(vm) {
    const v = this.vehicle;
    if (Math.abs(v.speed) > 12) return false;
    const c = Math.cos(v.heading), s = Math.sin(v.heading);
    const d = v.type.wid / 2 + 0.9, L = v.type.len / 2 + 0.9;
    // tenta sair pela esquerda, direita, traseira e frente
    const cand = [[c * d, -s * d], [-c * d, s * d], [-s * L, -c * L], [s * L, c * L]];
    let spot = null;
    for (const o of cand) {
      tmp.x = v.pos.x + o[0]; tmp.z = v.pos.z + o[1];
      const x0 = tmp.x, z0 = tmp.z;
      if (!this.physics.resolve(tmp, this.radius, 0) && !vm.pushOut(tmp, this.radius)) { spot = [x0, z0]; break; }
    }
    if (!spot) spot = [v.pos.x + cand[0][0], v.pos.z + cand[0][1]];
    v.driven = false;
    this.vehicle = null;
    this._detach();
    this.pos.x = spot[0]; this.pos.z = spot[1];
    this.pos.y = groundHeight(spot[0], spot[1]);
    this.vx = this.vz = this.vy = 0;
    this.heading = v.heading;
    this.grounded = true;
    this.sync();
    return true;
  }
}
