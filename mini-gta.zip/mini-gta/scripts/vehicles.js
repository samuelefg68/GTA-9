import * as THREE from 'three';
import { mat, damp, clamp, groundHeight, pick, shuffle } from './utils.js';

const UNIT = new THREE.BoxGeometry(1, 1, 1);
const WHEEL = new THREE.CylinderGeometry(0.38, 0.38, 0.28, 16).rotateZ(Math.PI / 2);
const TIRE = mat(0x141414), RIM = mat(0xc4c8cf);
const GLASS = new THREE.MeshLambertMaterial({ color: 0x24384d, transparent: true, opacity: 0.45 });
const HEAD = new THREE.MeshBasicMaterial({ color: 0xfff4c0 });
const TAIL = new THREE.MeshBasicMaterial({ color: 0xff2a2a });
const COLORS = [0xc0392b, 0x2980b9, 0xf1c40f, 0x27ae60, 0xecf0f1, 0x2c3e50, 0xe67e22, 0x8e44ad, 0x1abc9c, 0x95a5a6, 0x111111];

const TYPES = [
  { name: 'Sedan', len: 4.4, wid: 1.9, bodyH: 0.65, cabH: 0.62, cabL: 2.3, cabZ: -0.15, seatY: 0.55, maxSpeed: 34, maxRev: 10, accel: 14, brake: 30, steer: 0.55 },
  { name: 'Esportivo', len: 4.3, wid: 1.95, bodyH: 0.55, cabH: 0.5, cabL: 1.9, cabZ: -0.25, seatY: 0.42, maxSpeed: 46, maxRev: 11, accel: 22, brake: 36, steer: 0.5 },
  { name: 'Pickup', len: 5.0, wid: 2.05, bodyH: 0.8, cabH: 0.7, cabL: 2.0, cabZ: 0.5, seatY: 0.6, maxSpeed: 30, maxRev: 9, accel: 12, brake: 26, steer: 0.5 },
];
const NONE = { up: false, down: false, left: false, right: false, hand: false };
const SEAT_SCALE = 0.82;

function part(parent, material, x, y, z, sx, sy, sz, shadow = true) {
  const m = new THREE.Mesh(UNIT, material);
  m.scale.set(sx, sy, sz);
  m.position.set(x, y, z);
  m.castShadow = shadow;
  parent.add(m);
  return m;
}

export class Vehicle {
  constructor(type, color, x, z, heading) {
    this.type = type;
    this.name = type.name;
    this.home = { x, z, heading };
    this.pos = { x, y: 0, z };
    this.heading = heading;
    this.speed = 0;
    this.steer = 0;
    this.spin = 0;
    this.driven = false;
    this.radius = type.wid / 2 + 0.05;
    this.reach = type.len / 2 - this.radius - 0.1; // distância dos dois círculos de colisão ao centro
    this.fx = Math.sin(heading);
    this.fz = Math.cos(heading);

    const g = (this.group = new THREE.Group());
    const body = mat(color);
    const by = 0.3 + type.bodyH / 2;
    part(g, body, 0, by, 0, type.wid, type.bodyH, type.len);
    const cy = 0.3 + type.bodyH + type.cabH / 2;
    part(g, GLASS, 0, cy, type.cabZ, type.wid * 0.9, type.cabH, type.cabL, false);
    part(g, body, 0, cy + type.cabH / 2 + 0.03, type.cabZ, type.wid * 0.92, 0.06, type.cabL + 0.1);
    for (const s of [-1, 1]) {
      part(g, HEAD, s * type.wid * 0.34, by + 0.05, type.len / 2 + 0.01, 0.4, 0.18, 0.05, false);
      part(g, TAIL, s * type.wid * 0.34, by + 0.05, -type.len / 2 - 0.01, 0.4, 0.18, 0.05, false);
    }
    part(g, mat(0x222428), 0, 0.42, type.len / 2, type.wid * 0.98, 0.16, 0.1);
    part(g, mat(0x222428), 0, 0.42, -type.len / 2, type.wid * 0.98, 0.16, 0.1);

    this.wheels = [];
    this.pivots = [];
    for (const zs of [1, -1]) {
      for (const xs of [1, -1]) {
        const pivot = new THREE.Group();
        pivot.position.set(xs * (type.wid / 2 - 0.05), 0.38, zs * type.len * 0.32);
        const spin = new THREE.Group();
        const tire = new THREE.Mesh(WHEEL, TIRE);
        tire.castShadow = true;
        spin.add(tire);
        part(spin, RIM, 0, 0, 0, 0.32, 0.1, 0.6, false);
        part(spin, RIM, 0, 0, 0, 0.32, 0.6, 0.1, false);
        pivot.add(spin);
        g.add(pivot);
        this.wheels.push(spin);
        if (zs > 0) this.pivots.push(pivot);
      }
    }
    // Posição do motorista (lado esquerdo = +x), usada pelo jogador.
    this.seat = { x: type.wid * 0.22, y: type.seatY - 0.9 * SEAT_SCALE, z: type.cabZ - 0.1, s: SEAT_SCALE };
    this.sync();
  }

  drive(dt, inp) {
    const T = this.type;
    let s = this.speed;
    if (inp.up) s += (s < -0.3 ? T.brake : T.accel * (1 - Math.max(0, s) / T.maxSpeed)) * dt;
    else if (inp.down) s -= (s > 0.3 ? T.brake : T.accel * 0.7 * (1 + Math.min(0, s) / T.maxRev)) * dt;
    else {
      const f = (this.driven ? 4 : 10) * dt;
      s = Math.abs(s) <= f ? 0 : s - Math.sign(s) * f;
    }
    if (inp.hand) {
      const f = 38 * dt;
      s = Math.abs(s) <= f ? 0 : s - Math.sign(s) * f;
    }
    s -= s * Math.abs(s) * 0.0012 * dt; // arrasto aerodinâmico
    this.speed = clamp(s, -T.maxRev, T.maxSpeed);

    const target = (inp.left ? 1 : 0) - (inp.right ? 1 : 0);
    const maxSt = T.steer / (1 + Math.abs(this.speed) * 0.07);
    this.steer = damp(this.steer, target * maxSt, 9, dt);
    let turn = (this.speed / (T.len * 0.6)) * Math.tan(this.steer);
    if (inp.hand && Math.abs(this.speed) > 6) turn *= 1.8;
    this.heading += turn * dt;
    this.fx = Math.sin(this.heading);
    this.fz = Math.cos(this.heading);
    this.pos.x += this.fx * this.speed * dt;
    this.pos.z += this.fz * this.speed * dt;
    this.spin += (this.speed / 0.38) * dt;
  }

  sync() {
    this.group.position.set(this.pos.x, this.pos.y, this.pos.z);
    this.group.rotation.y = this.heading;
    for (const p of this.pivots) p.rotation.y = this.steer;
    for (const w of this.wheels) w.rotation.x = this.spin;
  }

  reset() {
    this.pos.x = this.home.x; this.pos.z = this.home.z; this.pos.y = 0;
    this.heading = this.home.heading;
    this.fx = Math.sin(this.heading); this.fz = Math.cos(this.heading);
    this.speed = 0; this.steer = 0; this.driven = false;
    this.sync();
  }
}

const tmp = { x: 0, z: 0 };

export class VehicleManager {
  constructor(scene, physics, notify) {
    this.scene = scene;
    this.physics = physics;
    this.notify = notify;
    this.list = [];
    this.crashCooldown = 0;
    this.input = { up: false, down: false, left: false, right: false, hand: false };
  }

  spawn(x, z, heading, typeIndex) {
    const type = typeIndex !== undefined ? TYPES[typeIndex] : pick(TYPES);
    const v = new Vehicle(type, pick(COLORS), x, z, heading);
    this.scene.add(v.group);
    this.list.push(v);
    return v;
  }

  populate(city) {
    const st = city.starterCar;
    this.spawn(st.x, st.z, st.heading, 0);
    const spots = [
      ...city.parkingSpots.filter(() => Math.random() < 0.3),
      ...shuffle(city.roadSpots.slice()).slice(0, 24),
    ];
    for (const s of spots) {
      if (this.list.some((v) => (v.pos.x - s.x) ** 2 + (v.pos.z - s.z) ** 2 < 64)) continue;
      this.spawn(s.x, s.z, s.heading);
    }
  }

  resetAll() { for (const v of this.list) v.reset(); }

  nearest(x, z, maxD) {
    let best = null, bd = maxD * maxD;
    for (const v of this.list) {
      const d = (v.pos.x - x) ** 2 + (v.pos.z - z) ** 2;
      if (d < bd) { bd = d; best = v; }
    }
    return best;
  }

  // Empurra um pedestre (círculo) para fora dos veículos. Retorna o veículo atingido, se houver.
  pushOut(p, r) {
    let hit = null;
    for (const v of this.list) {
      const lim = v.type.len / 2 + r + 0.5;
      const ddx = p.x - v.pos.x, ddz = p.z - v.pos.z;
      if (ddx * ddx + ddz * ddz > lim * lim) continue;
      for (let s = -1; s <= 1; s += 2) {
        const cx = v.pos.x + v.fx * v.reach * s, cz = v.pos.z + v.fz * v.reach * s;
        const dx = p.x - cx, dz = p.z - cz;
        const min = v.radius + r;
        const d2 = dx * dx + dz * dz;
        if (d2 < min * min) {
          const d = Math.sqrt(d2) || 0.01;
          p.x = cx + (dx / d) * min;
          p.z = cz + (dz / d) * min;
          hit = v;
        }
      }
    }
    return hit;
  }

  update(dt, controls) {
    const physics = this.physics;
    const inp = this.input;
    inp.up = controls.down('KeyW'); inp.down = controls.down('KeyS');
    inp.left = controls.down('KeyA'); inp.right = controls.down('KeyD');
    inp.hand = controls.down('Space');
    this.crashCooldown -= dt;

    for (const v of this.list) {
      if (!v.driven && v.speed === 0) continue; // carro parado: nada a simular
      v.drive(dt, v.driven ? inp : NONE);

      // colisão com construções/objetos: dois círculos (frente e traseira)
      let impact = 0;
      for (let s = 1; s >= -1; s -= 2) {
        tmp.x = v.pos.x + v.fx * v.reach * s;
        tmp.z = v.pos.z + v.fz * v.reach * s;
        const ox = tmp.x, oz = tmp.z, spd = v.speed;
        if (physics.resolve(tmp, v.radius)) {
          v.pos.x += tmp.x - ox;
          v.pos.z += tmp.z - oz;
          const dot = Math.abs(v.fx * physics.nx + v.fz * physics.nz);
          v.speed *= 1 - 0.9 * dot;
          impact = Math.max(impact, Math.abs(spd) * dot);
        }
      }
      if (impact > 9 && v.driven && this.crashCooldown <= 0) {
        this.notify('Batida!');
        this.crashCooldown = 1.5;
      }
      v.pos.y = damp(v.pos.y, groundHeight(v.pos.x, v.pos.z), 14, dt);
    }

    // colisão entre veículos, com troca simples de momento
    const L = this.list;
    for (let i = 0; i < L.length; i++) {
      const a = L[i];
      for (let j = i + 1; j < L.length; j++) {
        const b = L[j];
        const ddx = a.pos.x - b.pos.x, ddz = a.pos.z - b.pos.z;
        if (ddx * ddx + ddz * ddz > 36) continue;
        if (!a.driven && !b.driven && a.speed === 0 && b.speed === 0) continue;
        const ma = a.driven ? 3 : 1, mb = b.driven ? 3 : 1;
        const min = a.radius + b.radius;
        for (let sa = -1; sa <= 1; sa += 2) {
          for (let sb = -1; sb <= 1; sb += 2) {
            const dx = a.pos.x + a.fx * a.reach * sa - (b.pos.x + b.fx * b.reach * sb);
            const dz = a.pos.z + a.fz * a.reach * sa - (b.pos.z + b.fz * b.reach * sb);
            const d2 = dx * dx + dz * dz;
            if (d2 >= min * min) continue;
            const d = Math.sqrt(d2) || 0.01;
            const nx = dx / d, nz = dz / d, pen = min - d;
            a.pos.x += nx * pen * (mb / (ma + mb)); a.pos.z += nz * pen * (mb / (ma + mb));
            b.pos.x -= nx * pen * (ma / (ma + mb)); b.pos.z -= nz * pen * (ma / (ma + mb));
            const vn = (a.fx * a.speed - b.fx * b.speed) * nx + (a.fz * a.speed - b.fz * b.speed) * nz;
            if (vn < 0) {
              const j2 = -vn * 0.6;
              a.speed += (a.fx * nx + a.fz * nz) * j2 * (mb / (ma + mb));
              b.speed -= (b.fx * nx + b.fz * nz) * j2 * (ma / (ma + mb));
              if (-vn > 8 && (a.driven || b.driven) && this.crashCooldown <= 0) {
                this.notify('Batida!');
                this.crashCooldown = 1.5;
              }
            }
          }
        }
      }
    }
    for (const v of L) v.sync();
  }
}
