import { createHumanoid, animateHumanoid, rand, pick, damp, angleLerp, groundHeight } from './utils.js';

const SHIRTS = [0xd9534f, 0x5bc0de, 0xf0ad4e, 0x5cb85c, 0x9b59b6, 0xecf0f1, 0x34495e, 0xe67e22, 0x1abc9c, 0xff6fa5];
const PANTS = [0x2c3e50, 0x34495e, 0x4a4a4a, 0x1f3a5f, 0x6b4f2a, 0x222222, 0x556b2f];
const SKINS = [0xf1c9a5, 0xd9a066, 0xa86d3b, 0x7a4a2a, 0x4b2e1c, 0xffdbb4];
const HAIRS = [0x1a1a1a, 0x4b2e16, 0xc9a227, 0x8a8a8a, 0x7a2a1a];
const R = 0.35;

class NPC {
  constructor(scene) {
    this.model = createHumanoid({ shirt: pick(SHIRTS), pants: pick(PANTS), skin: pick(SKINS), hair: pick(HAIRS) });
    this.model.rotation.order = 'YXZ';
    this.model.scale.setScalar(rand(0.92, 1.08));
    scene.add(this.model);
    this.pos = { x: 0, y: 0, z: 0 };
    this.speed = rand(1.2, 2.3);       // cada NPC tem sua velocidade
    this.heading = 0;
    this.phase = rand(0, 6);
    this.node = null; this.target = null; this.prev = null;
    this.wait = 0; this.fallen = 0; this.stuck = 0;
  }
}

export class NPCManager {
  constructor(scene, physics, city, count = 60) {
    this.physics = physics;
    this.nodes = city.nodes;
    this.list = [];
    for (let i = 0; i < count; i++) this.list.push(new NPC(scene));
    this.reset();
  }

  reset() {
    for (const n of this.list) {
      n.node = pick(this.nodes);
      n.target = pick(n.node.n);
      n.prev = null;
      const t = Math.random();
      n.pos.x = n.node.x + (n.target.x - n.node.x) * t;
      n.pos.z = n.node.z + (n.target.z - n.node.z) * t;
      n.pos.y = groundHeight(n.pos.x, n.pos.z);
      n.heading = Math.atan2(n.target.x - n.node.x, n.target.z - n.node.z);
      n.wait = 0; n.fallen = 0; n.stuck = 0;
      n.model.rotation.x = 0;
    }
  }

  // Escolhe o próximo destino (canto de calçada vizinho), evitando voltar quando possível.
  _next(n) {
    const nb = n.target.n;
    let choice = null, count = 0;
    for (let i = 0; i < nb.length; i++) {
      if (nb[i] === n.node) continue;
      if (Math.random() * ++count < 1) choice = nb[i];
    }
    n.prev = n.node;
    n.node = n.target;
    n.target = choice || n.prev;
  }

  update(dt, vm, player) {
    const L = this.list;
    for (let i = 0; i < L.length; i++) {
      const n = L[i], p = n.pos, m = n.model;

      if (n.fallen > 0) {
        n.fallen -= dt;
        if (n.fallen <= 0) { m.rotation.x = 0; n.wait = 0.5; }
        continue;
      }

      let moving = false;
      if (n.wait > 0) n.wait -= dt;
      else {
        const dx = n.target.x - p.x, dz = n.target.z - p.z;
        const d = Math.hypot(dx, dz);
        if (d < 0.5) {
          this._next(n);
          if (Math.random() < 0.2) n.wait = rand(1, 4);
        } else {
          const step = n.speed * dt;
          p.x += (dx / d) * step; p.z += (dz / d) * step;
          n.heading = angleLerp(n.heading, Math.atan2(dx, dz), 1 - Math.exp(-8 * dt));
          moving = true;
        }
      }

      // evita outros NPCs
      for (let j = i + 1; j < L.length; j++) {
        const o = L[j];
        if (o.fallen > 0) continue;
        const dx = p.x - o.pos.x, dz = p.z - o.pos.z;
        const d2 = dx * dx + dz * dz;
        if (d2 < 0.5 && d2 > 1e-6) {
          const d = Math.sqrt(d2), push = (0.7 - d) * 0.5;
          p.x += (dx / d) * push; p.z += (dz / d) * push;
          o.pos.x -= (dx / d) * push; o.pos.z -= (dz / d) * push;
        }
      }
      // afasta-se do jogador a pé
      if (!player.vehicle) {
        const dx = p.x - player.pos.x, dz = p.z - player.pos.z;
        const d2 = dx * dx + dz * dz;
        if (d2 < 0.64 && d2 > 1e-6) {
          const d = Math.sqrt(d2);
          p.x += (dx / d) * (0.8 - d); p.z += (dz / d) * (0.8 - d);
        }
      }
      // veículos: empurra ou derruba se estiver rápido
      const hitV = vm.pushOut(p, R);
      if (hitV && Math.abs(hitV.speed) > 5) { n.fallen = 3; m.rotation.x = -Math.PI / 2; }

      // obstáculos: se ficar preso, dá meia-volta
      if (this.physics.resolve(p, R, p.y)) {
        n.stuck += dt;
        if (n.stuck > 0.5) {
          const t = n.target; n.target = n.node; n.node = t; n.stuck = 0;
        }
      } else n.stuck = Math.max(0, n.stuck - dt);

      p.y = damp(p.y, groundHeight(p.x, p.z), 12, dt);
    }

    for (const n of L) {
      const m = n.model;
      m.position.set(n.pos.x, n.pos.y + (n.fallen > 0 ? 0.2 : 0), n.pos.z);
      m.rotation.y = n.heading;
      if (n.fallen > 0) continue;
      n.phase += dt * n.speed * 3.2;
      animateHumanoid(m, n.phase, n.wait > 0 ? 0 : 0.5);
    }
  }
}
