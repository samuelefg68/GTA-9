import * as THREE from 'three';
import { rand } from './utils.js';

const SUN_DIR = new THREE.Vector3(80, 120, 60);

export class World {
  constructor(container) {
    this.renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.75));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    container.appendChild(this.renderer.domElement);

    this.scene = new THREE.Scene();
    this.scene.fog = new THREE.Fog(0xbcd9f2, 140, 620);
    this.camera = new THREE.PerspectiveCamera(65, 1, 0.2, 1400);

    // Iluminação: hemisférica (ambiente) + direcional (sol) com sombras que seguem o jogador.
    this.scene.add(new THREE.HemisphereLight(0xcfe6ff, 0x6b7a5a, 1.1));
    const sun = new THREE.DirectionalLight(0xfff1d6, 2.1);
    sun.castShadow = true;
    sun.shadow.mapSize.set(2048, 2048);
    const sc = sun.shadow.camera;
    sc.left = -90; sc.right = 90; sc.top = 90; sc.bottom = -90; sc.near = 10; sc.far = 400;
    sun.shadow.bias = -0.0004;
    sun.shadow.normalBias = 0.05;
    this.scene.add(sun, sun.target);
    this.sun = sun;

    // Céu em degradê (domo que acompanha a câmera).
    this.sky = new THREE.Mesh(
      new THREE.SphereGeometry(900, 24, 12),
      new THREE.ShaderMaterial({
        side: THREE.BackSide, depthWrite: false, fog: false,
        uniforms: { top: { value: new THREE.Color(0x3a78c9) }, bottom: { value: new THREE.Color(0xbcd9f2) } },
        vertexShader: 'varying float h; void main(){ h = normalize(position).y; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }',
        fragmentShader: 'uniform vec3 top; uniform vec3 bottom; varying float h; void main(){ gl_FragColor = vec4(mix(bottom, top, clamp(h * 1.4, 0.0, 1.0)), 1.0);\n#include <colorspace_fragment>\n}',
      })
    );
    this.sky.renderOrder = -2;
    this.scene.add(this.sky);

    this.sunDisc = new THREE.Mesh(new THREE.SphereGeometry(28, 16, 12), new THREE.MeshBasicMaterial({ color: 0xfff3b0, fog: false }));
    this.scene.add(this.sunDisc);

    // Nuvens: elipsoides achatados compartilhando geometria e material.
    const cloudGeo = new THREE.SphereGeometry(1, 10, 8);
    const cloudMat = new THREE.MeshBasicMaterial({ color: 0xffffff, fog: false, transparent: true, opacity: 0.92 });
    this.clouds = [];
    for (let i = 0; i < 14; i++) {
      const g = new THREE.Group();
      for (let j = 0; j < 4; j++) {
        const m = new THREE.Mesh(cloudGeo, cloudMat);
        m.scale.set(rand(25, 45), rand(8, 13), rand(15, 28));
        m.position.set(j * 28 - 42 + rand(-6, 6), rand(-3, 4), rand(-10, 10));
        g.add(m);
      }
      g.position.set(rand(-700, 700), rand(170, 240), rand(-700, 700));
      this.scene.add(g);
      this.clouds.push(g);
    }

    this.resize();
    window.addEventListener('resize', () => this.resize());
  }

  resize() {
    const w = window.innerWidth, h = window.innerHeight;
    this.renderer.setSize(w, h);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
  }

  update(dt, focus) {
    // A sombra acompanha o foco, "encaixada" em passos de 2 m para evitar tremulação.
    const fx = Math.round(focus.x / 2) * 2, fz = Math.round(focus.z / 2) * 2;
    this.sun.position.set(fx + SUN_DIR.x, SUN_DIR.y, fz + SUN_DIR.z);
    this.sun.target.position.set(fx, 0, fz);
    this.sun.target.updateMatrixWorld();

    const cp = this.camera.position;
    this.sky.position.copy(cp);
    this.sunDisc.position.set(cp.x + SUN_DIR.x * 7, cp.y + SUN_DIR.y * 7, cp.z + SUN_DIR.z * 7);
    for (const c of this.clouds) {
      c.position.x += dt * 4;
      if (c.position.x > 750) c.position.x = -750;
    }
  }

  render() {
    this.renderer.render(this.scene, this.camera);
  }
}
